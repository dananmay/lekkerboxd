import './assets/service-worker.ts-DTqAvkXZ.js';
