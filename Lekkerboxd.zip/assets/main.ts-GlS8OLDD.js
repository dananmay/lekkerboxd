import{d as x,i as v,e as S,a as w}from"./url-utils-BjFLQ3h6.js";function $(e){const r=[],t=e.querySelectorAll('.react-component[data-item-slug], [data-component-class="LazyPoster"]');for(const l of t){const i=A(l,e);i&&r.push(i)}if(r.length===0){const l=e.querySelectorAll(".poster-list li, .film-list li");for(const i of l){const n=D(i);n&&r.push(n)}}return r}function A(e,r){const t=e.getAttribute("data-item-slug");if(!t)return null;const l=e.getAttribute("data-item-name")||"",i=e.getAttribute("data-item-full-display-name")||l,{title:n,year:o}=m(i||t.replace(/-/g," ")),s=e.getAttribute("data-film-id")||"",a=e.querySelector(".poster, .film-poster");a?.getAttribute("data-watched"),a?.getAttribute("data-in-watchlist");const g=e.querySelector("img")?.getAttribute("src")||null,d=k(e,s,r),b=E(d),h=q(d),y=I(d);return{slug:t,title:n,year:o,rating:b,liked:h,reviewed:y,posterUrl:g,letterboxdUrl:`https://letterboxd.com/film/${t}/`}}function k(e,r,t){let l=e.nextElementSibling;if(l?.classList.contains("poster-viewingdata"))return l;if(r){const i=t.querySelector(`.poster-viewingdata[data-item-uid="film:${r}"]`);if(i)return i}return null}function E(e){if(!e)return null;const r=e.querySelector('.rating, [class*="rated-"]');if(!r)return null;const l=r.className.match(/rated-(\d+)/);if(l)return parseInt(l[1])/2;const i=r.textContent||"",n=(i.match(/★/g)||[]).length,o=(i.match(/½/g)||[]).length;return n>0||o>0?n+o*.5:null}function q(e){return e?e.querySelector(".icon-liked, .like-link-target .icon-liked")!==null:!1}function I(e){return e?e.querySelector(".icon-review, .has-review")!==null:!1}function m(e){const r=e.match(/^(.+?)\s*\((\d{4})\)\s*$/);return r?{title:r[1].trim(),year:parseInt(r[2])}:{title:e.trim(),year:null}}function D(e){const r=e.querySelector("[data-film-slug], [data-item-slug]");if(!r)return null;const t=r.getAttribute("data-film-slug")||r.getAttribute("data-item-slug");if(!t)return null;const l=e.querySelector("img"),i=l?.getAttribute("alt")||"",{title:n,year:o}=m(i||t.replace(/-/g," ")),s=e.querySelector('[class*="rated-"]');let a=null;if(s){const c=s.className.match(/rated-(\d+)/);c&&(a=parseInt(c[1])/2)}return{slug:t,title:n,year:o,rating:a,liked:e.querySelector(".icon-liked")!==null,reviewed:e.querySelector(".icon-review")!==null,posterUrl:l?.getAttribute("src")||null,letterboxdUrl:`https://letterboxd.com/film/${t}/`}}function L(e){const r=e.querySelectorAll(".paginate-pages li a, .pagination a");let t=1;for(const l of r){const i=l.textContent?.trim();if(i&&/^\d+$/.test(i)){const s=parseInt(i);s>t&&(t=s)}const o=(l.getAttribute("href")||"").match(/\/page\/(\d+)\//);if(o){const s=parseInt(o[1]);s>t&&(t=s)}}return t}function M(e){return/\/likes\/films/.test(e)?"likes":/\/films\/ratings/.test(e)?"ratings":/\/watchlist/.test(e)?"watchlist":/\/[a-zA-Z0-9_]+\/films\/?(\?|$)/.test(e)?"films":null}function f(){const e=window.location.href,r=w(e),t=M(e);if(!r||!t)return;const l=$(document),i=L(document),n=e.match(/\/page\/(\d+)/),o=n?parseInt(n[1]):1;if(console.log(`[LB Recs] Scraped ${l.length} films from ${r}/${t} (page ${o}/${i})`),l.length>0){const s={type:"SCRAPED_PAGE",username:r,films:l,pageType:t,page:o,totalPages:i};chrome.runtime.sendMessage(s)}}function P(e){const r=document.getElementById("lb-rec-overlay-root");if(r&&r.remove(),e.length===0)return;const t=document.createElement("div");t.id="lb-rec-overlay-root";const l=t.attachShadow({mode:"open"});l.innerHTML=`
    <style>
      :host {
        display: block;
        margin: 20px 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      .lb-rec-container {
        background: #14181c;
        border: 1px solid #2c3440;
        border-radius: 8px;
        padding: 16px;
        color: #9ab;
      }
      .lb-rec-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }
      .lb-rec-title {
        font-size: 14px;
        font-weight: 600;
        color: #def;
        text-transform: uppercase;
        letter-spacing: 1px;
      }
      .lb-rec-close {
        background: none;
        border: none;
        color: #678;
        cursor: pointer;
        font-size: 18px;
        padding: 4px 8px;
      }
      .lb-rec-close:hover { color: #def; }
      .lb-rec-grid {
        display: flex;
        gap: 8px;
        overflow-x: auto;
        padding-bottom: 8px;
      }
      .lb-rec-card {
        flex: 0 0 auto;
        width: 105px;
        text-decoration: none;
        color: inherit;
        transition: transform 0.15s;
      }
      .lb-rec-card:hover { transform: translateY(-2px); }
      .lb-rec-poster {
        width: 105px;
        height: 158px;
        border-radius: 4px;
        background: #1a2030;
        object-fit: cover;
      }
      .lb-rec-film-title {
        font-size: 11px;
        color: #def;
        margin-top: 4px;
        line-height: 1.3;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .lb-rec-film-year {
        font-size: 10px;
        color: #678;
      }
      .lb-rec-score {
        display: inline-block;
        font-size: 9px;
        background: #00c030;
        color: #fff;
        padding: 1px 4px;
        border-radius: 3px;
        margin-top: 2px;
      }
      .lb-rec-watchlist-badge {
        display: inline-block;
        font-size: 9px;
        background: #40bcf4;
        color: #fff;
        padding: 1px 4px;
        border-radius: 3px;
        margin-left: 4px;
      }
      .lb-rec-because {
        font-size: 9px;
        color: #678;
        margin-top: 2px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    </style>
    <div class="lb-rec-container">
      <div class="lb-rec-header">
        <span class="lb-rec-title">Recommended For You</span>
        <button class="lb-rec-close" title="Dismiss">&times;</button>
      </div>
      <div class="lb-rec-grid">
        ${e.map(n=>`
          <a class="lb-rec-card" href="${n.letterboxdUrl}" title="${u(n.title)} (${n.year})&#10;Score: ${n.score}/100&#10;Because you liked: ${n.hits.map(o=>o.seedFilmTitle).slice(0,3).join(", ")}">
            <img class="lb-rec-poster"
              src="${n.posterPath?`https://image.tmdb.org/t/p/w185${n.posterPath}`:""}"
              alt="${u(n.title)}"
              loading="lazy" />
            <div class="lb-rec-film-title">${u(n.title)}</div>
            <div class="lb-rec-film-year">${n.year||""}</div>
            <span class="lb-rec-score">${n.score}</span>
            ${n.onWatchlist?'<span class="lb-rec-watchlist-badge">Watchlist</span>':""}
            <div class="lb-rec-because">Because: ${n.hits.map(o=>o.seedFilmTitle).slice(0,2).join(", ")}</div>
          </a>
        `).join("")}
      </div>
    </div>
  `;const i=document.querySelector(".film-detail-content")||document.querySelector("#content")||document.querySelector("main")||document.body;i&&i!==document.body?i.parentNode?.insertBefore(t,i.nextSibling):document.body.appendChild(t),l.querySelectorAll(".lb-rec-poster").forEach(n=>{n.addEventListener("error",()=>{n.style.display="none"})}),l.querySelector(".lb-rec-close")?.addEventListener("click",()=>{t.remove()})}function u(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}chrome.runtime.onMessage.addListener((e,r,t)=>e.type==="RECOMMENDATIONS_READY"?(P(e.result.recommendations),t({ok:!0}),!1):(e.type==="REQUEST_SCRAPE"&&(f(),t({ok:!0})),!1));const p=x(document);if(p){console.log(`[LB Recs] Detected logged-in user: ${p}`);const e={type:"LOGGED_IN_USER",username:p};chrome.runtime.sendMessage(e)}f();if(v(window.location.href)){const e=S(window.location.href);if(e){const r=document.querySelector('.headline-1, h1.filmtitle, [itemprop="name"]'),t=document.querySelector(".releaseyear a, .year"),l=r?.textContent?.trim()||e.replace(/-/g," "),i=t?parseInt(t.textContent||""):null,n={type:"GET_FILM_RECOMMENDATIONS",filmSlug:e,filmTitle:l,filmYear:i};chrome.runtime.sendMessage(n)}}
