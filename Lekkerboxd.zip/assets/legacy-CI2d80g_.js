import{a6 as a}from"./disclose-version-CDM3uPK9.js";a();
