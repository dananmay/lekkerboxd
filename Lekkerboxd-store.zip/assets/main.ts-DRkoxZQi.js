import{d as y,i as v,e as w,a as k}from"./url-utils-BjFLQ3h6.js";function S(e){const r=[],t=e.querySelectorAll('.react-component[data-item-slug], [data-component-class="LazyPoster"]');for(const n of t){const o=$(n,e);o&&r.push(o)}if(r.length===0){const n=e.querySelectorAll(".poster-list li, .film-list li");for(const o of n){const l=M(o);l&&r.push(l)}}return r}function $(e,r){const t=e.getAttribute("data-item-slug");if(!t)return null;const n=e.getAttribute("data-item-name")||"",o=e.getAttribute("data-item-full-display-name")||n,{title:l,year:i}=g(o||t.replace(/-/g," ")),s=e.getAttribute("data-film-id")||"",a=e.querySelector(".poster, .film-poster");a?.getAttribute("data-watched"),a?.getAttribute("data-in-watchlist");const u=e.querySelector("img")?.getAttribute("src")||null,p=A(e,s,r),b=E(p),h=q(p),x=I(p);return{slug:t,title:l,year:i,rating:b,liked:h,reviewed:x,posterUrl:u,letterboxdUrl:`https://letterboxd.com/film/${t}/`}}function A(e,r,t){let n=e.nextElementSibling;if(n?.classList.contains("poster-viewingdata"))return n;if(r){const o=t.querySelector(`.poster-viewingdata[data-item-uid="film:${r}"]`);if(o)return o}return null}function E(e){if(!e)return null;const r=e.querySelector('.rating, [class*="rated-"]');if(!r)return null;const n=r.className.match(/rated-(\d+)/);if(n)return parseInt(n[1])/2;const o=r.textContent||"",l=(o.match(/★/g)||[]).length,i=(o.match(/½/g)||[]).length;return l>0||i>0?l+i*.5:null}function q(e){return e?e.querySelector(".icon-liked, .like-link-target .icon-liked")!==null:!1}function I(e){return e?e.querySelector(".icon-review, .has-review")!==null:!1}function g(e){const r=e.match(/^(.+?)\s*\((\d{4})\)\s*$/);return r?{title:r[1].trim(),year:parseInt(r[2])}:{title:e.trim(),year:null}}function M(e){const r=e.querySelector("[data-film-slug], [data-item-slug]");if(!r)return null;const t=r.getAttribute("data-film-slug")||r.getAttribute("data-item-slug");if(!t)return null;const n=e.querySelector("img"),o=n?.getAttribute("alt")||"",{title:l,year:i}=g(o||t.replace(/-/g," ")),s=e.querySelector('[class*="rated-"]');let a=null;if(s){const c=s.className.match(/rated-(\d+)/);c&&(a=parseInt(c[1])/2)}return{slug:t,title:l,year:i,rating:a,liked:e.querySelector(".icon-liked")!==null,reviewed:e.querySelector(".icon-review")!==null,posterUrl:n?.getAttribute("src")||null,letterboxdUrl:`https://letterboxd.com/film/${t}/`}}function D(e){const r=e.querySelectorAll(".paginate-pages li a, .pagination a");let t=1;for(const n of r){const o=n.textContent?.trim();if(o&&/^\d+$/.test(o)){const s=parseInt(o);s>t&&(t=s)}const i=(n.getAttribute("href")||"").match(/\/page\/(\d+)\//);if(i){const s=parseInt(i[1]);s>t&&(t=s)}}return t}function L(e){return/\/likes\/films/.test(e)?"likes":/\/films\/ratings/.test(e)?"ratings":/\/watchlist/.test(e)?"watchlist":/\/[a-zA-Z0-9_]+\/films\/?(\?|$)/.test(e)?"films":null}function f(){const e=window.location.href,r=k(e),t=L(e);if(!r||!t)return;const n=S(document),o=D(document),l=e.match(/\/page\/(\d+)/),i=l?parseInt(l[1]):1;if(console.log(`[LB Recs] Scraped ${n.length} films from ${r}/${t} (page ${i}/${o})`),n.length>0){const s={type:"SCRAPED_PAGE",username:r,films:n,pageType:t,page:i,totalPages:o};chrome.runtime.sendMessage(s).catch(()=>{})}}function P(e){const r=document.getElementById("lb-rec-overlay-root");if(r&&r.remove(),e.length===0)return;const t=document.createElement("div");t.id="lb-rec-overlay-root";const n=t.attachShadow({mode:"open"}),o=e.map(i=>{const s=i.year?String(i.year):"Unknown year",a=i.hits.map(u=>u.seedFilmTitle).slice(0,2).join(", "),c=i.posterPath?`<img class="lb-rec-poster"
          src="https://image.tmdb.org/t/p/w185${i.posterPath}"
          alt="${d(i.title)}"
          loading="lazy" />`:'<div class="lb-rec-poster lb-rec-poster-empty">No poster</div>';return`
      <a class="lb-rec-card" href="${i.letterboxdUrl}" title="${d(i.title)} (${s})&#10;Score: ${i.score}/100&#10;Because: ${a}">
        ${c}
        <div class="lb-rec-film-title">${d(i.title)}</div>
        <div class="lb-rec-meta-row">
          <div class="lb-rec-film-year">${d(s)}</div>
          <span class="lb-rec-score">${i.score}</span>
        </div>
        ${i.onWatchlist?'<span class="lb-rec-watchlist-badge">In Watchlist</span>':""}
        ${a?`<div class="lb-rec-because">Because you liked ${d(a)}</div>`:""}
      </a>
    `}).join("");n.innerHTML=`
    <style>
      :host {
        display: block;
        margin: 18px 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      .lb-rec-container {
        background: #14181c;
        border: 1px solid #2d3745;
        border-radius: 10px;
        padding: 14px;
        color: #9ab;
      }
      .lb-rec-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 4px;
        gap: 10px;
      }
      .lb-rec-title {
        font-size: 13px;
        font-weight: 600;
        color: #def;
        text-transform: uppercase;
        letter-spacing: 0.9px;
      }
      .lb-rec-subtitle {
        font-size: 10px;
        color: #7f91a7;
        margin-bottom: 10px;
      }
      .lb-rec-close {
        background: none;
        border: none;
        color: #678;
        cursor: pointer;
        font-size: 17px;
        padding: 2px 6px;
        line-height: 1;
        border-radius: 6px;
      }
      .lb-rec-close:hover {
        color: #def;
        background: rgba(255, 255, 255, 0.08);
      }
      .lb-rec-grid {
        display: flex;
        gap: 10px;
        overflow-x: auto;
        padding-bottom: 8px;
      }
      .lb-rec-card {
        flex: 0 0 auto;
        width: 122px;
        background: #1a222e;
        border: 1px solid #2e3c4c;
        border-radius: 8px;
        padding: 7px;
        text-decoration: none;
        color: inherit;
        transition: transform 0.15s, border-color 0.15s;
      }
      .lb-rec-card:hover {
        transform: translateY(-2px);
        border-color: #46607b;
      }
      .lb-rec-poster {
        width: 108px;
        height: 162px;
        border-radius: 6px;
        background: #1a2030;
        object-fit: cover;
        display: block;
      }
      .lb-rec-poster-empty {
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6f8095;
        font-size: 10px;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        border: 1px dashed #324559;
      }
      .lb-rec-film-title {
        font-size: 11px;
        color: #def;
        margin-top: 6px;
        line-height: 1.25;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        min-height: 28px;
      }
      .lb-rec-meta-row {
        margin-top: 4px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
      }
      .lb-rec-film-year {
        font-size: 10px;
        color: #678;
      }
      .lb-rec-score {
        display: inline-block;
        font-size: 10px;
        background: #0ab65a;
        color: #fff;
        padding: 1px 7px;
        border-radius: 999px;
        font-weight: 600;
      }
      .lb-rec-watchlist-badge {
        display: inline-block;
        font-size: 9px;
        background: #2f9bcc;
        color: #fff;
        padding: 2px 6px;
        border-radius: 999px;
        margin-top: 4px;
      }
      .lb-rec-because {
        font-size: 10px;
        color: #8ea0b7;
        margin-top: 4px;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .lb-rec-grid::-webkit-scrollbar { height: 8px; }
      .lb-rec-grid::-webkit-scrollbar-track {
        background: #1a222f;
        border-radius: 999px;
      }
      .lb-rec-grid::-webkit-scrollbar-thumb {
        background: #304256;
        border-radius: 999px;
      }
    </style>
    <div class="lb-rec-container">
      <div class="lb-rec-header">
        <span class="lb-rec-title">Recommended For This Film</span>
        <button class="lb-rec-close" title="Dismiss" aria-label="Dismiss recommendations">&times;</button>
      </div>
      <div class="lb-rec-subtitle">${e.length} picks from your taste profile</div>
      <div class="lb-rec-grid">
        ${o}
      </div>
    </div>
  `;const l=document.querySelector(".film-detail-content")||document.querySelector("#content")||document.querySelector("main")||document.body;l&&l!==document.body?l.parentNode?.insertBefore(t,l.nextSibling):document.body.appendChild(t),n.querySelectorAll(".lb-rec-poster").forEach(i=>{i.addEventListener("error",()=>{const s=document.createElement("div");s.className="lb-rec-poster lb-rec-poster-empty",s.textContent="No poster",i.replaceWith(s)})}),n.querySelector(".lb-rec-close")?.addEventListener("click",()=>{t.remove()})}function d(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}chrome.runtime.onMessage.addListener((e,r,t)=>e.type==="RECOMMENDATIONS_READY"?(P(e.result.recommendations),t({ok:!0}),!1):(e.type==="REQUEST_SCRAPE"&&(f(),t({ok:!0})),!1));const m=y(document);if(m){console.log(`[LB Recs] Detected logged-in user: ${m}`);const e={type:"LOGGED_IN_USER",username:m};chrome.runtime.sendMessage(e).catch(()=>{})}f();if(v(window.location.href)){const e=w(window.location.href);if(e){const r=document.querySelector('.headline-1, h1.filmtitle, [itemprop="name"]'),t=document.querySelector(".releaseyear a, .year"),n=r?.textContent?.trim()||e.replace(/-/g," "),o=t?parseInt(t.textContent||""):null,l={type:"GET_FILM_RECOMMENDATIONS",filmSlug:e,filmTitle:n,filmYear:o};chrome.runtime.sendMessage(l).catch(()=>{})}}
